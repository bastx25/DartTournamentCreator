using DTC.Api.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace DTC.Api.Models
{
    [Table("Matches")]
    public class Match
    {
        public int Id { get; set; }

        public int? RoundId { get; set; }  // Foreign Key (Required)
        public Round? Round { get; set; }

        public int? GroupId { get; set; }  // Foreign Key (Optional for knockout matches)
        public Group? Group { get; set; }

        public int? BoardId { get; set; } // Foreign Key (Optional / Nullable)
        public Board? Board { get; set; }

        public MatchStatus Status { get; set; } = MatchStatus.Scheduled;
        public DateTimeOffset? PlannedStart { get; set; }
        public DateTimeOffset? PlannedEnd { get; set; }
        public DateTimeOffset? ActualStart { get; set; }
        public DateTimeOffset? ActualEnd { get; set; }

        // Navigation Properties
        public ICollection<MatchParticipant> Participants { get; set; } = new List<MatchParticipant>();
    }
}
